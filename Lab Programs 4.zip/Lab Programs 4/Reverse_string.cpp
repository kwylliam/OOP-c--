#include<iostream>
#include<cstring>
#include<cmath>
using namespace std;

int main(){

	string s;
	int length;
	cout<<"Enter a sentence: ";

	getline(cin,s);
	length=s.length();

	char result[length+1];

	int i=length-1, j=0;

	while(j<length){
		result[j]=s[i];
		i--;
		j++;
	}

	result[length]='\0';

	cout<<result;
	return 0;
}